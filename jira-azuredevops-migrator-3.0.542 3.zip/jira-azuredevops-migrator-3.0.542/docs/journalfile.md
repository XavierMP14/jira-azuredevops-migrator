# Migration journal file

## Structure

The journal file contains data on the following format:

```txt
Source item id;target item id;revision
```

## Example file

```txt
SCRUM-16;9191;0
SCRUM-18;9192;0
SCRUM-19;9193;0
SCRUM-20;9194;0
SCRUM-21;9195;0
SCRUM-22;9196;0
SCRUM-23;9197;0
SCRUM-18;9192;1
SCRUM-18;9192;2
SCRUM-19;9193;1
SCRUM-19;9193;2
SCRUM-20;9194;1
```
