# Attachments journal file

## Structure

The attachments journal file contains data on the following format:

    ```txt
    attachment;id
    ```

## Example file

    ```txt
    10015;2231232
    10015-thumb;2231233
    ```
