### Jira Azure DevOps Migrator PRO, price plan

#### Included features

* Jira Azure DevOps Migrator PRO + bootstrapper utility
* Support for a limited number of Jira organizations/servers
* Support for an unlimited number of Azure DevOps organizations/servers
* Support over email

#### Price

$1000 / Jira organization (or server) / month

</br>

The extension can be evaluated during a 30 days period.
All prices excl. VAT.

[Contact us](mailto:support.jira-migrator@solidify.dev) for more information.
