﻿using System.Collections.Generic;

namespace Migration.Common.Config
{
    public class LinkMap
    {
        public List<Link> Links { get; set; }
    }
}