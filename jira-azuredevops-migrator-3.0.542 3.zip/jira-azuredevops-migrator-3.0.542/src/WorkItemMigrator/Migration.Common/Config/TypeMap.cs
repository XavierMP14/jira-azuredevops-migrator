﻿using System.Collections.Generic;

namespace Migration.Common.Config
{
    public class TypeMap
    {
        public List<Type> Types { get; set; }
    }
}