﻿using System.Collections.Generic;

namespace Migration.Common.Config
{
    public class Mapping
    {
        public List<Value> Values { get; set; }
    }
}