﻿using System.Collections.Generic;

namespace Migration.Common.Config
{
    public class RepositoryMap
    {
        public List<Repository> Repositories { get; set; }
    }
}